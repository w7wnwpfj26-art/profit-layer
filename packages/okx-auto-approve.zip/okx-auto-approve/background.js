// OKX Wallet Auto Approve - Background Script
// 管理插件状态和设置
// v2.0.0: 增强配置支持

// 默认配置
const DEFAULT_CONFIG = {
  enabled: true,
  autoApprove: true,
  approveDelay: 500, // 延迟毫秒数，避免检测
  whitelistMode: false,
  whitelist: [],
  blacklist: [],
  approveCount: 0,
  lastApproveTime: null,
  // v2.0.0 新增
  preferredChainId: null // 首选链 ID，供切链用（可选）
};

// 初始化存储
chrome.runtime.onInstalled.addListener(async () => {
  const config = await chrome.storage.local.get('config');
  if (!config.config) {
    await chrome.storage.local.set({ config: DEFAULT_CONFIG });
  }
  console.log('OKX Auto Approve 已安装');
});

// 监听来自 content script 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getConfig') {
    chrome.storage.local.get('config').then(({ config }) => {
      sendResponse({ config: config || DEFAULT_CONFIG });
    });
    return true; // 保持消息通道开启
  }
  
  if (request.action === 'updateConfig') {
    chrome.storage.local.set({ config: request.config }).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'recordApproval') {
    chrome.storage.local.get('config').then(({ config }) => {
      const updatedConfig = {
        ...config,
        approveCount: (config.approveCount || 0) + 1,
        lastApproveTime: new Date().toISOString()
      };
      chrome.storage.local.set({ config: updatedConfig });
    });
    return true;
  }
  
  if (request.action === 'log') {
    console.log(`[OKX Auto Approve] ${request.message}`, request.data || '');
    return true;
  }
});

// 监听标签页更新
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    // 检测是否是 DeFi 网站
    const isDeFiSite = /uniswap|aave|curve|compound|pancakeswap|sushiswap|balancer|yearn/i.test(tab.url);
    if (isDeFiSite) {
      console.log('检测到 DeFi 网站:', tab.url);
    }
  }
});
