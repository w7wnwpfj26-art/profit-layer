// OKX Wallet Auto Approve - Injected Script
// 注入到页面上下文，可以访问 window.okxwallet
// v2.0.0: 新增 window.coldWallet API 对接 Dashboard

(function() {
  console.log('[OKX Auto Approve] 注入脚本已加载 v2.0.0');

  // 获取钱包提供者
  function getProvider() {
    return window.okxwallet || window.ethereum;
  }

  // 检测 OKX 钱包
  function detectOKXWallet() {
    if (window.okxwallet || window.okex) {
      console.log('[OKX Auto Approve] 检测到 OKX 钱包');
      window.postMessage({ type: 'OKX_WALLET_DETECTED' }, '*');
      return true;
    }
    return false;
  }

  // 立即检测
  detectOKXWallet();

  // 如果还没检测到，等待钱包注入
  if (!window.okxwallet && !window.okex) {
    const checkInterval = setInterval(() => {
      if (detectOKXWallet()) {
        clearInterval(checkInterval);
        // 钱包检测到后初始化 coldWallet API
        initColdWalletAPI();
      }
    }, 500);

    // 10秒后停止检测
    setTimeout(() => clearInterval(checkInterval), 10000);
  }

  // 监听 OKX 钱包的请求
  const originalRequest = window.okxwallet?.request;
  if (originalRequest) {
    window.okxwallet.request = async function(...args) {
      console.log('[OKX Auto Approve] 钱包请求:', args);
      const result = await originalRequest.apply(this, args);
      console.log('[OKX Auto Approve] 钱包响应:', result);
      return result;
    };
  }

  // ========== window.coldWallet API ==========
  // 供 Dashboard WalletAutomationBridge 调用

  function initColdWalletAPI() {
    if (window.coldWallet) return; // 已初始化

    window.coldWallet = {
      /**
       * 获取当前钱包地址
       * @returns {Promise<string>} 钱包地址
       */
      getAddress: async function() {
        const provider = getProvider();
        if (!provider) {
          throw new Error('OKX 钱包未安装或未注入，请先安装 OKX Wallet 扩展');
        }

        try {
          const accounts = await provider.request({ method: 'eth_requestAccounts' });
          if (accounts && accounts.length > 0) {
            console.log('[OKX Auto Approve] 获取地址成功:', accounts[0]);
            return accounts[0];
          }
          throw new Error('未获取到钱包地址，请确认已连接 OKX 钱包');
        } catch (err) {
          console.error('[OKX Auto Approve] 获取地址失败:', err);
          throw err;
        }
      },

      /**
       * 签名并发送交易
       * @param {Object} txPayload 交易参数
       * @param {string} [txPayload.chainId] 链ID（可选，若提供则先切链）
       * @param {string} txPayload.to 目标地址
       * @param {string} [txPayload.from] 发送地址
       * @param {string} [txPayload.value] 金额（wei）
       * @param {string} [txPayload.data] 调用数据
       * @param {string} [txPayload.gas] Gas 限制
       * @param {string} [txPayload.gasPrice] Gas 价格
       * @returns {Promise<string>} 交易哈希
       */
      signTransaction: async function(txPayload) {
        const provider = getProvider();
        if (!provider) {
          throw new Error('OKX 钱包未安装或未注入，请先安装 OKX Wallet 扩展');
        }

        console.log('[OKX Auto Approve] 收到签名请求:', txPayload);

        try {
          // 1. 如果指定了 chainId，先切换链
          if (txPayload.chainId) {
            const chainIdHex = typeof txPayload.chainId === 'number' 
              ? '0x' + txPayload.chainId.toString(16) 
              : txPayload.chainId;
            
            console.log('[OKX Auto Approve] 切换到链:', chainIdHex);
            try {
              await provider.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: chainIdHex }]
              });
            } catch (switchError) {
              // 4902 表示链未添加，可以忽略或尝试添加
              if (switchError.code !== 4902) {
                console.warn('[OKX Auto Approve] 切链失败，继续尝试发送交易:', switchError);
              }
            }
          }

          // 2. 获取发送地址
          let from = txPayload.from;
          if (!from) {
            const accounts = await provider.request({ method: 'eth_requestAccounts' });
            from = accounts[0];
          }

          // 3. 构建交易参数
          const txParams = {
            from: from,
            to: txPayload.to,
            value: txPayload.value || '0x0',
            data: txPayload.data || '0x',
          };

          // 可选参数
          if (txPayload.gas) txParams.gas = txPayload.gas;
          if (txPayload.gasPrice) txParams.gasPrice = txPayload.gasPrice;
          if (txPayload.maxFeePerGas) txParams.maxFeePerGas = txPayload.maxFeePerGas;
          if (txPayload.maxPriorityFeePerGas) txParams.maxPriorityFeePerGas = txPayload.maxPriorityFeePerGas;
          if (txPayload.nonce) txParams.nonce = txPayload.nonce;

          console.log('[OKX Auto Approve] 发送交易:', txParams);

          // 4. 发送交易（这会弹出 OKX 确认窗口）
          const txHash = await provider.request({
            method: 'eth_sendTransaction',
            params: [txParams]
          });

          console.log('[OKX Auto Approve] 交易发送成功:', txHash);
          return txHash;
        } catch (err) {
          console.error('[OKX Auto Approve] 签名/发送交易失败:', err);
          throw err;
        }
      }
    };

    console.log('[OKX Auto Approve] window.coldWallet API 已初始化');
    // 通知页面 coldWallet 已就绪
    window.postMessage({ type: 'COLD_WALLET_READY' }, '*');
  }

  // 监听来自 content script 的消息请求
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    
    // 处理签名请求（通过消息方式调用）
    if (event.data.type === 'COLD_WALLET_SIGN_REQUEST') {
      const { requestId, payload } = event.data;
      console.log('[OKX Auto Approve] 收到消息签名请求:', requestId, payload);

      try {
        if (!window.coldWallet) {
          initColdWalletAPI();
        }
        const result = await window.coldWallet.signTransaction(payload);
        window.postMessage({
          type: 'COLD_WALLET_SIGN_RESPONSE',
          requestId: requestId,
          success: true,
          result: result
        }, '*');
      } catch (err) {
        window.postMessage({
          type: 'COLD_WALLET_SIGN_RESPONSE',
          requestId: requestId,
          success: false,
          error: err.message || String(err)
        }, '*');
      }
    }

    // 处理获取地址请求
    if (event.data.type === 'COLD_WALLET_GET_ADDRESS') {
      const { requestId } = event.data;
      console.log('[OKX Auto Approve] 收到获取地址请求:', requestId);

      try {
        if (!window.coldWallet) {
          initColdWalletAPI();
        }
        const address = await window.coldWallet.getAddress();
        window.postMessage({
          type: 'COLD_WALLET_ADDRESS_RESPONSE',
          requestId: requestId,
          success: true,
          result: address
        }, '*');
      } catch (err) {
        window.postMessage({
          type: 'COLD_WALLET_ADDRESS_RESPONSE',
          requestId: requestId,
          success: false,
          error: err.message || String(err)
        }, '*');
      }
    }
  });

  // 立即初始化 coldWallet API（如果钱包已存在）
  if (getProvider()) {
    initColdWalletAPI();
  }
})();
