// OKX Wallet Auto Approve - Content Script
// 注入到所有页面，检测并自动确认 OKX 钱包弹窗
// v2.0.0: 修复按钮选择器，新增 Dashboard 消息通信

(async function() {
  // 获取配置
  let config = null;
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getConfig' });
    config = response.config;
  } catch (err) {
    console.error('获取配置失败:', err);
    return;
  }

  if (!config || !config.enabled) {
    return;
  }

  console.log('[OKX Auto Approve] 内容脚本已加载 v2.0.0');

  // 注入脚本到页面上下文
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('injected.js');
  script.onload = function() {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(script);

  // 监听来自注入脚本和页面的消息
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    
    // OKX 钱包检测通知
    if (event.data.type === 'OKX_WALLET_DETECTED') {
      console.log('[OKX Auto Approve] 检测到 OKX 钱包');
    }
    
    // coldWallet API 就绪通知
    if (event.data.type === 'COLD_WALLET_READY') {
      console.log('[OKX Auto Approve] coldWallet API 已就绪');
    }
    
    // 签名响应（从 injected.js 返回）
    if (event.data.type === 'COLD_WALLET_SIGN_RESPONSE') {
      console.log('[OKX Auto Approve] 收到签名响应:', event.data);
      // 响应会被 injected.js 直接返回给页面，这里只是日志
    }
    
    // 地址响应（从 injected.js 返回）
    if (event.data.type === 'COLD_WALLET_ADDRESS_RESPONSE') {
      console.log('[OKX Auto Approve] 收到地址响应:', event.data);
    }
  });

  // OKX 钱包弹窗选择器 - v2.0.0 修复：只保留合法 CSS 选择器
  const OKX_SELECTORS = {
    // 确认按钮的合法 CSS 选择器（移除了无效的 :contains 选择器）
    confirmButtons: [
      'button[data-testid="confirm-footer-button"]',
      'button[class*="confirm"]',
      '.okxweb3-connect-dialog button[type="button"]',
      '[class*="okx"] button[class*="primary"]',
      '[class*="okx"] button[class*="confirm"]',
      'button[class*="btn-primary"]',
      'button[class*="approve"]',
      'button[class*="sign"]'
    ],
    // 弹窗容器
    dialogContainers: [
      '[class*="okxweb3"]',
      '[class*="okx-wallet"]',
      '[id*="okx"]',
      'iframe[src*="okx"]'
    ]
  };

  // 按文本匹配按钮的关键词（大小写不敏感）
  const CONFIRM_BUTTON_TEXTS = [
    '确认', 'confirm', 'approve', '签名', 'sign', 
    '同意', 'agree', '授权', 'authorize', '提交', 'submit'
  ];

  // 检查是否是黑名单网站
  function isBlacklisted() {
    if (!config.blacklist || config.blacklist.length === 0) return false;
    const currentUrl = window.location.href;
    return config.blacklist.some(domain => currentUrl.includes(domain));
  }

  // 检查是否是白名单网站（如果启用白名单模式）
  function isWhitelisted() {
    if (!config.whitelistMode) return true;
    if (!config.whitelist || config.whitelist.length === 0) return false;
    const currentUrl = window.location.href;
    return config.whitelist.some(domain => currentUrl.includes(domain));
  }

  // v2.0.0 新增：按文本内容查找按钮
  function findButtonByText(doc) {
    const buttons = doc.querySelectorAll('button');
    for (const button of buttons) {
      const text = (button.textContent || button.innerText || '').trim().toLowerCase();
      // 检查按钮文本是否包含关键词
      for (const keyword of CONFIRM_BUTTON_TEXTS) {
        if (text.includes(keyword.toLowerCase())) {
          // 检查按钮是否可见
          if (isButtonVisible(button)) {
            return button;
          }
        }
      }
    }
    return null;
  }

  // 检查按钮是否可见且可点击
  function isButtonVisible(button) {
    if (!button) return false;
    if (button.disabled) return false;
    if (button.offsetParent === null) return false;
    const rect = button.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  // 在指定文档中通过 CSS 选择器查找按钮
  function findButtonBySelector(doc, selector) {
    try {
      const button = doc.querySelector(selector);
      if (button && isButtonVisible(button)) {
        return button;
      }
    } catch (e) {
      // 无效选择器，跳过
    }
    return null;
  }

  // 获取所有可访问的文档（主文档 + 同源 iframe）
  function getAllDocuments() {
    const docs = [document];
    const iframes = document.querySelectorAll('iframe');
    for (const iframe of iframes) {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          docs.push(iframeDoc);
        }
      } catch (e) {
        // 跨域 iframe 无法访问，跳过
      }
    }
    return docs;
  }

  // 查找并点击确认按钮
  async function findAndClickConfirmButton() {
    if (isBlacklisted()) {
      console.log('[OKX Auto Approve] 当前网站在黑名单中，跳过');
      return false;
    }

    if (!isWhitelisted()) {
      console.log('[OKX Auto Approve] 当前网站不在白名单中，跳过');
      return false;
    }

    // 获取所有可访问的文档
    const docs = getAllDocuments();
    let foundButton = null;

    // 方法 1：通过 CSS 选择器查找
    for (const selector of OKX_SELECTORS.confirmButtons) {
      for (const doc of docs) {
        foundButton = findButtonBySelector(doc, selector);
        if (foundButton) {
          console.log(`[OKX Auto Approve] 通过选择器找到按钮: ${selector}`);
          break;
        }
      }
      if (foundButton) break;
    }

    // 方法 2：通过按钮文本查找（v2.0.0 新增）
    if (!foundButton) {
      for (const doc of docs) {
        foundButton = findButtonByText(doc);
        if (foundButton) {
          const text = (foundButton.textContent || '').trim();
          console.log(`[OKX Auto Approve] 通过文本匹配找到按钮: "${text}"`);
          break;
        }
      }
    }

    // 找到按钮后点击
    if (foundButton) {
      // 延迟点击，模拟人类行为
      await new Promise(resolve => setTimeout(resolve, config.approveDelay || 500));
      
      // 点击按钮
      foundButton.click();
      
      console.log('[OKX Auto Approve] 已自动点击确认按钮');
      
      // 记录批准
      chrome.runtime.sendMessage({ 
        action: 'recordApproval'
      });
      
      // 通知用户
      showNotification('✅ 已自动确认交易');
      
      return true;
    }
    
    return false;
  }

  // 显示通知
  function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #10b981;
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 999999;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 14px;
      font-weight: 500;
      animation: slideIn 0.3s ease-out;
    `;
    notification.textContent = message;
    
    // 添加动画
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideIn {
        from {
          transform: translateX(400px);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.animation = 'slideIn 0.3s ease-out reverse';
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  // 使用 MutationObserver 监听 DOM 变化
  const observer = new MutationObserver(async (mutations) => {
    if (!config.autoApprove) return;

    // 检查是否出现了 OKX 弹窗
    for (const mutation of mutations) {
      if (mutation.addedNodes.length > 0) {
        // 延迟一小段时间，确保弹窗完全渲染
        await new Promise(resolve => setTimeout(resolve, 200));
        
        // 尝试找到并点击确认按钮
        const clicked = await findAndClickConfirmButton();
        if (clicked) {
          break;
        }
      }
    }
  });

  // 开始观察
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // 定期检查（作为后备方案）
  setInterval(async () => {
    if (config.autoApprove) {
      await findAndClickConfirmButton();
    }
  }, 1000);

  console.log('[OKX Auto Approve] 监听器已启动');
})();
